# Prompt para o Google AI Studio — Autopreenchimento via Pokerole-Data

Cole este prompt no chat do AI Studio dentro do projeto da ficha:

---

Quero adicionar autopreenchimento de Pokémon na minha ficha de Pokérole. Implemente o seguinte:

**Fonte de dados**: use o dataset público do projeto Pokerole-Data (o mesmo que alimenta o PokéroleDex, https://pokeroledex.nl/), disponível no GitHub em `Pokerole-Software-Development/Pokerole-Data`, pasta `v3.0`. Cada Pokémon tem um arquivo JSON individual nessa pasta. Busque a lista de arquivos via:

`https://api.github.com/repos/Pokerole-Software-Development/Pokerole-Data/contents/v3.0/Pokemon`

E o conteúdo de cada Pokémon via raw:

`https://raw.githubusercontent.com/Pokerole-Software-Development/Pokerole-Data/master/v3.0/Pokemon/<NOME_DO_ARQUIVO>.json`

**Comportamento desejado**:
1. No campo "espécie" do Pokémon na ficha (componente `PokemonCard.tsx`), quando o usuário digitar ou selecionar um nome, busque o Pokémon correspondente nesse dataset (ignorando maiúsculas/acentos, e aceitando nomes em português e inglês).
2. Ao encontrar, preencha automaticamente:
   - `tipo1` / `tipo2` (a partir do campo de tipos do JSON)
   - `baseStats` (hp, atk, def, spatk, spdef, spd)
   - `habilidade` (abilities disponíveis, deixando o usuário escolher se houver mais de uma)
   - `golpes` (movimentos base/learnset, mapeando nome, tipo, poder e efeito para `PokemonGolpe`)
   - `weak` (fraquezas/resistências de tipo, se existirem no dataset)
   - sprite/imagem, usando a base de sprites: `https://raw.githubusercontent.com/Willowlark/Pokerole-Data/master/images/HomeSprites/<sprite_filename>`
3. Não sobrescreva campos que o usuário já preencheu manualmente (nome do Pokémon, felicidade, notas, etc.) — só complete campos vazios ou pergunte antes de sobrescrever.
4. Faça isso com um `fetch` direto no client (sem precisar de chave de API, é um repositório público), com cache em memória (ex: um `Map`) pra não buscar o mesmo Pokémon duas vezes.
5. Trate erros graciosamente: se o Pokémon não for encontrado no dataset, não quebre a ficha — apenas não preencha os campos automaticamente e mostre um aviso discreto.
6. Adicione um pequeno indicador de loading (spinner ou texto "buscando dados...") enquanto a busca acontece.

Mantenha o estilo visual e a estrutura de componentes já existentes no projeto. Não use a API do Gemini para isso — é busca direta de dados estruturados, não precisa de IA generativa.

---
